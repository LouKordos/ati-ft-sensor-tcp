# ATI FT Sensor TCP

Python Package for reading out Force and Torque data from an ATI NetFT sensor via TCP. Existing solutions I found used UDP and I wanted something reliable. This means performance might suffer a bit so you will have to compare and benchmark if it is sufficient for your use case.